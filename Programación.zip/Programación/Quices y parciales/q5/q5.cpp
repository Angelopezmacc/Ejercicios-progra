
#include <iostream>
#include <wchar.h> //Acepta caracteres utf-8
using namespace std;

bool validar (int x, int y, int z){
  int d;
  int e;
  d = y+z; //Se crea una constante que represente y+z
  if (x % d == 0){ //Garantiza que devuelva true, utilizando el módulo de la operación
    return true;
  }
  else{
    return false; //En caso contratio retorna false
  }
}

int main (void){
  bool h; //Esta variable va a recibir el resultado al llamar la función validar
  int a; //Primer número
  int b; //Segundo número
  int c; //Tercer número
  cout << "Este programa recibe tres número x, y, z. Retorna true si x es divisible entre y+z, y retorna false si x no es divisible entre y+z:" << endl;
  cout << "Ingrese el primer número: "; //1er input
  cin >> a;
  cout << "Ingrese el segundo número: "; //2do input
  cin >> b;
  cout << "Ingrese el tercer número: "; //3er input
  cin >> c;

  h = validar(a, b, c); //Se llama a la función validar con los valores obtenidos de los inputs

  cout << "Los números validados son: " << h <<endl; //Se imprime el resultado

  return 0;
}
