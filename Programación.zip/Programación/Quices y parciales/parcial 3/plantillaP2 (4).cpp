#include<iostream>
#include<cmath>
using namespace std;

void greatest_prime_number(int, int&);

int main() {
  int n;
  int p;
  cout << "Ingrese n: ";
  cin >> n;
  greatest_prime_number(n, p);
  cout << "El mayor primo menor que n es: " << p << endl;
}

void greatest_prime_number(int n, int &p) {

}
