#include <iostream>
using namespace std;

void foo(double *p) {
  /*b)

    Su código aquí

  */
  
  /*c)

    Su código aquí

  */
}


int main() {
  double x=5, y=2;

  /*a)
  
    Su código aquí
  
  */
  
  foo(p);

  cout << "x: " << x << endl;
  cout << "y: " << y << endl;
  
  return 0;
}
