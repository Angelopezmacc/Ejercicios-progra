
#include <iostream> //Importación de librería de input-output
#include <cmath> //Importación de librería matemática
#include <wchar.h> //Importación de librería para manejo de caracteres
using namespace std;


float tempValidation(){
 float p = 0;
 //Your code here
 //Your code here
 return p;
}
int main (void){

  float z=0;
  cout << "Este programa captura valores de temperatura y retorna el promedio"<< endl;
  z = tempValidation();
  cout << "El promedio de las temperaturas ingresadas fue: " << z << endl;
  return 0;
}
