//se importan las librerias correspondientes
#include <iostream>
#include <wchar.h> //Acepta caracteres utf-8
#include <cmath>
using namespace std;

// se crea la función que calcula el área del triángulo
void triangle_area (float b, float h, float &a){
  a = (b*h)/2;
}

//se crea la función principal
int main (void){
  //se definen lasa variables
  float b,h,a;
  //se le solicitan los datos al usuario
  std::cout << "Ingrese el valor de la base" << '\n';
  std::cin >> b;
  std::cout << "Ingrese el valor de la altura" << '\n';
  std::cin >> h;
  //se invoca la función que recibe los parámetros ingresados por el usuario
  triangle_area(b,h,a);
  //se imprime el valor calculado en la función
  std::cout << "El valor del área es: "<< a << '\n';
  return 0;

}
