from NumeroComplejo import NumeroComplejo
import sys

def test(did_pass):
    """  Print the result of a test.  """
    linenum = sys._getframe(1).f_lineno   # Get the caller's line number.
    if did_pass:
        msg = "Test at line {0} ok.".format(linenum)
    else:
        msg = ("Test at line {0} FAILED.".format(linenum))
    print(msg)

z1 = NumeroComplejo(3,4)
z2 = NumeroComplejo(0,4)

test(z1.modulo() == 5.0)
test(z1.argumento() == 53.13010235415598)
test(z2.modulo() == 4.0)
test(z2.argumento() == 90)


