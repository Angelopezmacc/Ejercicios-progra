import math
class NumeroComplejo:
    
    def __init__(self, a, b):
        self.a=a
        self.b=b
    
    def modulo(self):
        z=math.sqrt(self.a**2+self.b**2)
        return z

    def argumento(self):
        if self.a==0:
            arg1=90
            return arg1
        if self.a !=0:
            arg2 = math.atan(self.b/self.a)*180/math.pi
            return arg2
        
    def __str__(self):
        impr="{0}+{1}".format(self.a,self.b)
        return impr
    

