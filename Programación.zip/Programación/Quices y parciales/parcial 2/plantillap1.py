

def char_to_ascci(cad):
    cadena_vacia =" "
    for ascci in cad:
        if ord(ascci)<=57 and ord(ascci)<=49:
                cadena_vacia=cadena_vacia+ascci
        else:
            cad=ord(ascci)
            cadena_vacia=cadena_vacia+str(cad)
    return cadena_vacia
            

#BOE
cad = "aB1c5"

print("El valor en ascci es: ",char_to_ascci(cad))
