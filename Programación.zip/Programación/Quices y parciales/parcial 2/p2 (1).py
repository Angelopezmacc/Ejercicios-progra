#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct  4 18:18:57 2019

@author: urosario
"""

import math

#Función de predicción de casos de infección en Colombia
def prediction_covid(d):
    cons = 10
    e = math.e
    power = 0.23*d
    y = cons*(math.pow(e, power)) #Se hace por partes, y se utiliza la librería math para el n´mero e y las potencias.
    return y

#Función para crear un diccionario para almacenar los datos
def generating_dictionary(s, d, y):
    s[str(d)] = str(y) #Agrega valores al diccionario.

#Función para almacenar los datos de manera persistente
def store_at_disk(s):
    database = open("database.txt", "w") #Se abre el archivo en modo escribir
    database.write("DATABASE WITH COVID PREDICTIONS FOR COLOMBIA\n") #Genera el título de la tabla
    database.write("Día \t Casos\n")#Genera el títulode cada columna
    for key in s: #Revisa cada llave del diccionario s
        database.write(str(key) + "\t" + str(s.get(key, "dato faltante")) + "\n" ) #Itera esto y escribe la key en forma de string, con un espacio (tab), y después busca el valor asignado a esa llave en forma de string, en caso de que no halla un dato, devuelve que hay un dato faltante, y finalmente sigue a la siguiente línea.
    database.close() #Cierra el archivo
#Validación de que la función de predicción este correctamente implementada
def testSuite():    
    if round(prediction_covid(28)) != 6264:
        return False
    if round(prediction_covid(29)) != 7884:
        return False
    if round(prediction_covid(30)) != 9923:
        return False
    if round(prediction_covid(31)) != 12489:
        return False
    return True

#### No modificar el código desde este punto hacia abajo ####

#### 1. Uso de la función prediction_covid(d) - No modificar este código ####
y1 = prediction_covid(28) #Generation of prediction values
y2 = prediction_covid(29)
y3 = prediction_covid(30)
y4 = prediction_covid(31)

if testSuite() == False: #Validation that values are correct
    error_de_validacion = ValueError("Error en la función prediction_covid() \n Corregir antes de continuar") #Creando un objeto de tipo ValueError
    raise error_de_validacion 


#### 2. Uso de la función generating_dictionary(s, d, y) - No modificar este código ####
s={} #Almacenamiento en el diccionario
generating_dictionary(s, 28, round(y1))
generating_dictionary(s, 29, round(y2))
generating_dictionary(s, 30, round(y3))
generating_dictionary(s, 31, round(y4))
print(s)


#### 3. Uso de la función store_at_disk(s) - No modificar este código ###
store_at_disk(s) #Almacenamiento persistente
