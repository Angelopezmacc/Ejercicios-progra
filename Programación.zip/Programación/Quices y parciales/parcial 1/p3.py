#BEGINING-OF-PROGRAM
def celsius_to_farenheit(c):
    f=1.8*c+32
    return f
#BEGINNING-OF-EXECUTION

temp1=celsius_to_farenheit(26)#Se invoca la función con un valor de entrada de 26
temp2=celsius_to_farenheit(8)#Se invoca la función con un valor de entrada de 8
print("El equivalente en grados farenheit de 28 grados celcius es: ",temp1,"grados farenheit")#Se imprime el resultado de la función para c=26
print("El equivalente en grados farenheit de 6 grados celcius es: ",temp2, "grados Farenheit")#Se imprime el resultado de la función para c=8

#END-OF-EXECUTION
#END-OF-PROGRAM



