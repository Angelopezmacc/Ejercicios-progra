#BEGINING-OF-PROGRAM
import turtle
turtle.setup(400,400)#Define las medidas de la ventana
wn = turtle.Screen()#Crea la ventana 
wn.bgcolor("white")#asigna el color blanco a la ventana
wn.title("Manuelita draws an Spiral composed by Squares")#Le asigna un t��tulo a la ventana

manuelita = turtle.Turtle()#crea la tortuga y le asigna un nombre
manuelita.color("blue")#Define el color del lapiz con el que la tortuga dibuja
def cuadrado(t, size):#define la funcion cuadrado que recibe a la tortuga y el largo del cuadrado
    for i in range(4):#Iteracion para que la instruccion se repita cuatro veces
        t.forward(size)
        t.right(90)

def estrella(t,size):
    for i in range(5):
        t.forward(size)
        t.right(145)
    
def espiral(t,size): #crea la funcion espiral que recibe la tortuga y el largo del cudrado más grande
    sz=[size/16,size/8,size/4,size/2,size]#sz es una lista que coge el valor ingresado de size en la funcion sz y lo divide con el fin de que cada cuadrado sea el doble del anterior
    for a in sz:#Iteracion en sz
        cuadrado(t,a)
        t.right(90)
        t.forward(a)
        
    
    

#BEGINNING-OF-EXECUTION

#espiral(manuelita, 200)#ejecuta la funcion espiral que recibe la tortuga y el valor del cuadrado grande
estrella(manuelita,50)


turtle.mainloop()
turtle.done()
turtle.bye()

#END-OF-EXECUTION
#END-OF-PROGRAM
