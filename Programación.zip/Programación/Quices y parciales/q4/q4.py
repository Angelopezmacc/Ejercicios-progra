#BEGINNING-OF-PROGRAM
import sys

def test(pasa):
    lnum=sys._getframe(1).f_lineno
    if pasa:
        msg = "prueba en la linea {0} ok".format(lnum)
    else:
        msg="prueba en la linea {0} falló".format(lnum)
    print(msg)

def ciudades(c):
    z=0#crea un contador   
    for (ID_aeronave,ciudades,capacidad_carga,numero_pasajeros) in database_wingo:#recorre la tupla
        for q in ciudades:#recorre los elementos de la lista de ciudades
            if q==c:
                z=z+1#suma al contador 1 en caso que la condición se cumpla
    return z

def testSuite():#se crea el testSuite
    test(ciudades("Leticia") == 2)
    test(ciudades("Bogota") == 4)
    test(ciudades("Popayan") == 1)
    test(ciudades("Cali") == 0)  

#BEGINNING-OF-EXECUTION

a1 = (9990, ["Quibdo", "Bogota", "Popayan", "Leticia"], 20, 115)
a2 = (9991, ["Bogota", "Pasto", "Leticia"], 15, 90)
a3 = (9992, ["Quibdo", "Pasto", "Bogota", "Monteria", "Medellin"], 17, 95)
a4 = (9993, ["Quibdo", "Pasto", "Bogota"], 20, 115)

database_wingo = [a1, a2, a3, a4]

testSuite()

#END-OF-EXECUTION
#END-OF-PROGRAM