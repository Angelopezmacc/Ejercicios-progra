# -*- coding: utf-8 -*-
"""
Created on Sat Mar 12 17:09:21 2022

@author: Ángel
"""

import sys


def day_add(day,n):
    week = ["Lunes","Martes","Miércoles","Jueves","Viernes",'Sábado',"Domingo"]
    dia = 0
    for i in range(len(week)):
        if week[i] == day:
            dia = dia + i
    
    if n > 0:
        new_week = week * n
        print(new_week[n+dia])
    elif n == 0:
        print(week[dia])
    else:
        print("El número ingresado es negativo")
        
# day_add("Lunes",4)  
# day_add("Martes",0)
# day_add("Martes",14)
# day_add("Domingo",100)
         
def test(pasa):
    lnum=sys._getframe(1).f_lineno
    if pasa:
        msg = "prueba en la linea {0} ok".format(lnum)
    else:
        msg="prueba en la linea {0} falló".format(lnum)
    print(msg)
    
def testSuite():

    test(day_add("Lunes",4) == "Viernes")
    test(day_add("Martes",0) == "Martes")
    test(day_add("Martes",14) == "Martes")
    test(day_add("Domingo",100) == "Martes")
    


testSuite()