#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 12 09:30:06 2020

@author: hipatia
"""
'''
Reto con 2 instancias de la Tortuga:
1. Cree la instancia manuelita de color violeta con lápiz rosa de grosor 3
2. Cree la instancia alex de color rojo con lápiz negro de grosor 1
3. Haga que manuelita dibuje un triángulo de lado 120
4. Haga que alex dibuje un pentágono de lado 60
'''

import turtle


nlados=input("¿De cuántos lados quiere su polígono?")
nladose=int(nlados)
angulointerno= ((nladose - 2)*180)/ nladose
print(angulointerno)
print("El valor del angulo interno es: ", angulointerno)
print("El valor del angulo interno de un poligono de", nladose, " es: ", angulointerno)


turtle.setup(400,300)
wn = turtle.Screen()
wn.bgcolor("lightgreen")
wn.title("Hi manuelita and alex!")

manuelita = turtle.Turtle()
alex = turtle.Turtle() 

manuelita.shape("turtle")
manuelita.color("purple")
manuelita.pencolor("pink")
manuelita.pensize(3)

alex.shape("turtle")
alex.color("red")
alex.pencolor("black")
alex.pensize(1)

manuelita.forward(120)
manuelita.left(120)
manuelita.forward(120)
manuelita.left(120)
manuelita.forward(120)
manuelita.left(120)

alex.forward(60)
alex.left(72)
alex.forward(60)
alex.left(72)
alex.forward(60)
alex.left(72)
alex.forward(60)
alex.left(72)
alex.forward(60)
alex.left(72)


turtle.mainloop()
turtle.done()
turtle.bye()
