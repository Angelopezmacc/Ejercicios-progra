#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 10:38:24 2020

@author: daniel
"""

import sys



def dayName(x):
    if x == 1:
        return("Lunes")
    elif x == 2:
        return("Martes")
    elif x == 3:
        return("Miercoles")
    elif x == 4:
        return("Jueves")
    elif x == 5:
        return("Viernes")
    elif x == 6:
        return("Sábado")
    elif x == 7:
        return("Domingo")
    else:
        return(None)
        
    

def test(pasa):
    """Imprime el resultado de una prueba"""
    lnum = sys._getframe(1).f_lineno #Obtiene el número de línea
    if pasa:
        msg = "Prueba en la línea {0} ok.".format(lnum)
        print(msg)
    else:
        msg = "Prueba en la línea {0} FALLÓ.".format(lnum)
        print(msg)
        
def testSuite():
    """Corre el conjunto de pruebas en este módulo"""
    test(dayName(1) == "Lunes")
    test(dayName(5) == "Viernes")
    test(dayName(42) == None)
testSuite()





