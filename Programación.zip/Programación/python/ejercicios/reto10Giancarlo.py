#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 11:11:36 2020

@author: hipatia
"""
import time
h = time.strftime("%H")
hh = int(h)
nombre= input("ingrese su nombre: ")

if (nombre == "admin"):
    print("hola admin. usted tiene acceso las 24 horas ")
elif ((nombre != "admin") and (hh>6)and(hh<18)):
    print("hola", nombre, "bienvenido al servidor son las", hh, "horas" )
    
else:
    print("lo siento, son las ", hh, "horas, no es posible acceder en este horario" )
    
    
    
    
    
    
    
    
    