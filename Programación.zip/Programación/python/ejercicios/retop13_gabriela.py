#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 10:38:24 2020

@author: daniel
"""

import sys

def c2f(c):
    f = round((c*1.8)+32)
    return f

def f2c(f):
    c = round((f-32)/1.8)
    return c
    
def malValorAbsoluto(x):
    if x < 0:
        return -x
    elif x > 0:
        return x
    else:
        return 0

def test(pasa):
    """Imprime el resultado de una prueba"""
    lnum = sys._getframe(1).f_lineno #Obtiene el número de línea
    if pasa:
        msg = "Prueba en la línea {0} ok.".format(lnum)
        print(msg)
    else:
        msg = "Prueba en la línea {0} FALLÓ.".format(lnum)
        print(msg)
        
def testSuite():
    """Corre el conjunto de pruebas en este módulo"""
    test(f2c(212) == 100)
    test(f2c(32) == 0)
    test(f2c(-40) == -40)
    test(f2c(36) == 2)
    test(f2c(37) == 3)
    test(f2c(38) == 3)
    test(f2c(39) == 4)
    
def testSuite2():
    """Corre el conjunto de pruebas en este módulo"""
    test(c2f(0) == 32)
    test(c2f(100) == 212)
    test(c2f(-40) == -40)
    test(c2f(12) == 54)
    test(c2f(18) == 64)
    test(c2f(-48) == -54)
    
testSuite()
print("")
testSuite2()



