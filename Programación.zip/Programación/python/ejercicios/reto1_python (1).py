#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Extienda el programa con lo siguiente:

1. Antes de crear la ventana pida al usuario que ingrese el color de fondo
2. Antes de crear la tortuga pida al usuario el color de la tortuga
3. Antes de comenzar a dibujar pida al usuario el color del lápiz
"""
# Giancarlo Gonzalez
# Nicolas Botero 
# Angel Lopez

import turtle



turtle.setup(400,300)
wn = turtle.Screen()

wn.bgcolor(input("qué color de fondo desea: "))
wn.title("Hola manuelita!")

manuelita = turtle.Turtle()
manuelita.color(input("que color de manuelita desea: "))
manuelita.pensize(3)
manuelita.pencolor(input("ingrese el color de lapiz in inglish please: "))

manuelita.forward(50)
manuelita.left(120)
manuelita.forward(50)
manuelita.left(120)
manuelita.forward(50)
manuelita.left(120)

turtle.mainloop()
turtle.done()
turtle.bye()

