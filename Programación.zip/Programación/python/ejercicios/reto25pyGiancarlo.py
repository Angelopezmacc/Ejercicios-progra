#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 13 10:57:06 2020

@author: hipatia
"""

'''Escriba una función que inserte, al inicio de todos los elementos de una lista, 
una cadena de caracteres dada. Suponga que los elementos de la lista de entrada 
siempre pueden ser convertidos a cadenas de caracteres, str. 
La función debe retornar la lista modificada. 

Note que el tipo de dato de los elementos de la lista no necesariamente son enteros.'''


import sys

def adding (list1, c):
    z = []
    
    for m in list1:
        j = c+str(m)
        
        z.append(j)
    return z
    
    


def test(pasa):
    lnum=sys._getframe(1).f_lineno
    if pasa:
        msg = "prueba en la linea {0} ok".format(lnum)
    else:
        msg="prueba en la linea {0} fallo".format(lnum)
    print(msg)
    
def testSuite():
    test(adding([1,2,3,4], 'e') == ['e1', 'e2', 'e3', 'e4'])
    test(adding(['q','p','g'], 'A') == ['Aq', 'Ap', 'Ag'])
    test(adding([1,2.3,4.5], '-') == ['-1', '-2.3', '-4.5'])

testSuite()
print(adding([1,2,3,4],"e"))