#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 24 18:32:58 2020

@author: juliana
"""
import sys

def cuadrados(c):
    d = {}
    if c >= 0:
        for x in range(1,c+1):
            d[x] = x*x                        
        #print("diccionario: ",d)
        #print("Valor 3 del diccionario",d.get(3))
        return d
    

def test(pasa):
    lnum=sys._getframe(1).f_lineno
    if pasa:
        msg = "prueba en la linea {0} ok".format(lnum)
    else:
        msg="prueba en la linea {0} fallo".format(lnum)
    print(msg)
    
def testSuite():
    test(cuadrados(-32) == None)
    test(cuadrados(0) == {})
    test(cuadrados(2) == {1: 1, 2: 4})
    test(cuadrados(5) == {1: 1, 2: 4, 3: 9, 4: 16, 5: 25})

testSuite()
  
    