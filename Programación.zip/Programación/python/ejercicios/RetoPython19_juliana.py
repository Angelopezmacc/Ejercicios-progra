
x1 = (10002, 99550, [56,43,22], ["China"], ["Quibdo", "Pasto", "Popayan", "Leticia"])  
x2 = (10003, 100550, [45, 57, 21], ["Bangladesh"], ["Cartagena", "Barranquilla", "Medellin", "Leticia"])
x3 = (10004, 220550, [65,53,19], ["Bangladesh"], ["Popayan", "Pasto", "Cartagena", "Barranquilla"])
x4 = (10005, 79550, [86,47,52], ["Pakistan"], ["Bogota", "Barranquilla", "Popayan", "Bucaramanga"]) 
x5 = (10006, 300550, [56,27,12], ["Pakistan"], ["Quibdo", "Bogota", "Cartagena", "Leticia"]) 
x6 = (10007, 400000, [75,38,29], ["China"], ["Quibdo", "Medellin", "Cali", "Barranquilla"]) 

Database_falabella = [x1, x2, x3, x4, x5, x6]


def PaisProcedencia(C):
	index = 0
	for (id, pr, v, pp, c) in Database_falabella:
		for i in pp:
			if i == C:
				index += 1
	print(index, "Productos de ", C)


#--------------------------------------------------
	
def VolumenMaximo(d):
    indexv = 0
    for (id, pr, v, pp, c) in Database_falabella:
        n=v[0]*v[1]*v[2]
#        for j in v:
#            n = v[0] * v[1] * v[2]
#            break
#            return n
        if n <= d:
            indexv += 1
    print(indexv, "Productos de volumen menor a", d,"cm^3.\n")
    
#--------------------------------------------------

def City(U):
	indexc = 0
	for (id, pr, v, pp, c) in Database_falabella:
		for k in c:
			if k == U:
				indexc += 1
	print(indexc, "Productos disponibles en",U,".")
    
#--------------------------------------------------

PaisProcedencia("China")
PaisProcedencia("Pakistan")
PaisProcedencia("Bangladesh")
VolumenMaximo(20000)
City("Cartagena")
City("Cali")
City("Barranquilla")
City("Medellin")
City("Bogota")
City("Quibdo")
City("Pasto")
City("Leticia")
City("Bucaramanga")
City("Popayan")