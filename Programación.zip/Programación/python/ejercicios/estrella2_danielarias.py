#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 14 10:16:33 2020

@author: hipatia
"""

import turtle

#Here define the function (the NEW-INSTRUCTION remembering to Karel)
def estrella(t, size):
    """La tortuga t dibuja una estrella de lado size"""
    for i in range(5):
        t.forward(size)
        t.left(144)
        
#Here start the code that use the functions (the BEGIN-OF-EXECUTION remembering to karel)
def makewindow(col, tit):
    turtle.setup(400,300)
    wn = turtle.Screen()
    wn.bgcolor(col)
    wn.title(tit)
    return wn

def maketurtle(col1,sz1):
    tortuga = turtle.Turtle()
    tortuga.color(col1)
    tortuga.pensize(sz1)   
    return tortuga

def cerrar():
    turtle.mainloop()
    turtle.done()
    turtle.bye()
    

ventana = makewindow("blue","Manuelita")  
manuelita = maketurtle("red",3)
estrella(manuelita, 70)
adios = cerrar()

