#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar 13 12:22:11 2020

@author: daniel
"""
'''
Escriba un programa que lea una cadena de caracteres y retorna las letras junto 
con el número de veces que aparece cada letra. 
Como caso de prueba, si la cadena de caracteres  de entrada es 
"ThiS is a String with Upper and lower case Letters", la función debería retornar:
     
{'a': 3, 'c': 1, 'd': 1, 'e': 5, 'g': 1, 'h': 2, 'i': 4, 'l': 2, 'n': 2, 'o': 1, 'p': 2, 'r': 4, 's': 5, 't': 5, 'u': 1, 'w': 2}

Note que solamente se imprimen las letras que se encuentran en la cadena de
caracteres. Mayúsculas y minúsculas deben tratarse como una sola letra.
'''
#Solucion 1
def r(text):
    cont={}
    for i in text:
        cont[i]=cont.get(i,0)+1
    return cont
d=r("asas")
print(d)


#Solucion 2
def r2(text):
    cont={}
    for i in text:
        cont[i]=0
    for i in range(len(text)):
        cont[text[i]]=cont[text[i]]+1
    return cont
t=r2("asdsdfs")
print(t)



