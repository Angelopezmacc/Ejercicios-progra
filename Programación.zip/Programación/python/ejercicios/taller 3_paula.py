#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 15 08:56:08 2020

@author: hipatia
"""

import turtle

def square (t, size):

    for i in range (4): # dibuja el cuadrado mas grande
        
        t.forward(size)
        t.left(90)
         
def square2(t,size):
    t.begin_fill()
   
    for o in range (4):# dibuja el cuadrado del inetrior del cuadrado mas grande
        t.forward(size/2)
        t.left(90)
       
    t.end_fill()      
    t.forward(size/2)
    t.left(90)
    t.forward(size/2)
    t.right(90)  
    return size
    
def bigsquare(t,a1,a2,b,c,size): # da las especificaciones que se desean
    t.penup()
    t.setpos(a1,a2)
    t.pendown()
    t.fillcolor(b)
    t.pencolor(c)
    for d in range (8): # nuemero de repeticiones de los cuadrados internos
        square(t, size)
        square2(t, size)
        size = size/2
        
def makewindow(col, tit):
    wn=turtle.Screen()
    wn.bgcolor(col)
    wn.title(tit)
    return wn

def close ():
    turtle.mainloop()
    turtle.done()
    turtle.bye()


mora=turtle.Turtle()
makewindow("white", "hello")
bigsquare(mora,-10,30,"green", "purple",300)

close()



