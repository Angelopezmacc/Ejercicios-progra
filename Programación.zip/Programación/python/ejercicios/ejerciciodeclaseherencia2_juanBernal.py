#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 17 08:18:11 2020

@author: daniel
"""

'''
Herencia explicita:
La clase hija redefine el método de la clase madre
'''
class Parent(object):
    def cocinar(self):
        print("Tengo habilidades culinarias")
    def jugarfutbol(self):
        print("Tengo habilidades con el futbol")
    def override(self):
        print("Method of the parent")

class Child(Parent):
    def override(self):  #Estoy sobreescribiendo el metodo heredado
        print("Now is the mehod of the child")
    def jugarfutbol(self): #El hijo sobreescribe el metodo
        print("Yo tengo habilidades para el futbol, pero prefiero la natacion")

dad = Parent()
son = Child()

son.jugarfutbol()
son.cocinar()
son.override() #Son did not accept the heritated method


"""
Dada la implementación de la clase Abeja (mostrada abajo), implemente la clase
hija reina_perezosa (con los métodos ponerHuevos que imprime Pongo huevos!, emitirFeromonas
que imprime Emito feromonas! y el metodo volar que lo sobreescribe con su propia
versión de volar que imprime no me gusta volar!)
Finalmente, cree un objeto de tipo Reina y demuestre que la Reina puede acceder 
a objetos heredados de la clase Abeja y a su propia versión de volar"""

class Abeja :
    def __init__ ( self , sp = " apis mellifera " ) :
        self . especie = sp
    def volar ( self ) :
        print ( " Estoy volando ! " )
    def alimentarse ( self ) :
        print ( " Me estoy alimentando ! " )

class Reina(Abeja):
    def volar(self): #Sobreescribir el metodo
        print("Ahora planea")
   
padre = Abeja()
hijo = Reina()

padre.volar()     
hijo.volar()
hijo.alimentarse()








