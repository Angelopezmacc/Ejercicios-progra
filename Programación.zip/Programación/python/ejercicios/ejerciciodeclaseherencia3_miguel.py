#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 17 08:18:11 2020

@author: daniel
"""

'''
Herencia con alteración
La clase hija usa el método de la clase madre, pero añade cosas
antes y/o después
'''

class Parent(object):
    def altered(self):
        print("PARENT altered()")
class Child(Parent):
    def altered(self):
        print("CHILD, BEFORE PARENT altered()")
        super(Child, self).altered() #Here i am refering to the method of the parent
        print("CHILD, AFTER PARENT altered()")

dad = Parent()
son = Child()
dad.altered()
son.altered()

'''
Dada la implementación de la clase Abeja (mostrada abajo), implemente la clase
hija reina_hiperactiva (con los métodos ponerHuevos que imprime Pongo huevos!, emitirFeromonas
que imprime Emito feromonas! y el metodo volar que invoca al metodo volar de la
madre 3 veces)
Finalmente, cree un objeto de tipo Reina y demuestre que la Reina puede acceder 
a objetos heredados de la clase Abeja y a su propia versión de volar

class Abeja :
    def __init__ ( self , sp = " apis mellifera " ) :
        self . especie = sp
    def volar ( self ) :
        print ( " Estoy volando ! " )
    def alimentarse ( self ) :
        print ( " Me estoy alimentando ! " )
'''


class Abeja :
    def __init__ ( self , sp = " apis mellifera " ) :
        self . especie = sp
    def volar ( self ) :
        print ( " Estoy volando ! " )
    def alimentarse ( self ) :
        print ( " Me estoy alimentando ! " )
        
class reina_hiperactiva(Abeja) :
    def ponerHuevos(self):
        print("Pongo huevos!")
    def emitirFeromonas(self):
        print("Emito Feromonas!")
    def volar(self):
        super(reina_hiperactiva,self).volar()
        super(reina_hiperactiva,self).volar()
        super(reina_hiperactiva,self).volar()
            

abeja1 = reina_hiperactiva()

abeja1.volar()

abeja1.alimentarse()
abeja1.ponerHuevos()
abeja1.emitirFeromonas()

    


        