#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 14 07:03:59 2020

@author: daniel
"""

"""
Escriba una función llamada arearectangulo que reciba los lados de un rectángulo a y b, y retorne su área c. 
Posteriormente llame a la función definida previamente ingresando 2 valores cualquiera para a y para b
Imprima el valor del area retornado.
"""

alto = int(input("Cual es el alto de su rectangulo?"))
ancho = int(input("Cual es el ancho de su rectangulo?"))

#Here define the function (the NEW-INSTRUCTION remembering to Karel)
def arearectangulo(a,b):
    c = a * b
    return c

#Here start the code that use the functions (the BEGIN-OF-EXECUTION remembering to karel)
    
print("El area de su rectanguo es de: ", arearectangulo(alto,ancho))
print("Aqui abajo podremos ver otras areas de otros rectangulos...")

area1 = arearectangulo(3,5)
print("el area es ", area1)

area2 = arearectangulo(4,2)
print("el area es ", area2)

area3 = arearectangulo(4,5)
print("el area es ", area3)
