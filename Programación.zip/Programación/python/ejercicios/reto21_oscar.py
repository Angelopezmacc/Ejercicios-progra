#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar  6 11:43:40 2020

@author: hipatia
"""

def removedordeletras():
    frase = str(input("ESCRIBA LA FRASE: "))
    frase = frase.lower() # vuelve todo minuscula
    nuevafrase = []
    vocal = ["a","e","i","o","u"]
    for letra in frase: # letra es la letra o espacio
        if letra not in vocal: # si la letra no esta en la vocal entonces pegue la letra o espacio
            nuevafrase.append(letra) # append pega la letra
    
    nuevo = ""
    for i in nuevafrase:
        nuevo = nuevo + i
    
    return nuevo

nuevo= removedordeletras()
print(nuevo)

















