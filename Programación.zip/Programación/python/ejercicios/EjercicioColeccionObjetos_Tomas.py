#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 06:55:54 2020

@author: daniel
"""

class Carta:
    
    palos = ["Tréboles","Diamantes","Corazones","Picas"]
    rangos = ["-","Az","2","3","4","5","6","7","8","9", "10","J","Q","K"]
    
    def __init__(self, palo=0, rango=0):
        self.palo = palo
        self.rango = rango
    
    def __str__(self):
        return self.rangos[self.rango] + " de " + self.palos[self.palo]
    
    def cmp(self,other):
        """Compara palos"""
        if self.palo > other.palo: return 1
        if self.palo < other.palo: return -1
        """Palos son iguales, compara rango"""
        if self.rango > other.rango: return 1
        if self.rango < other.rango: return -1
        """Cartas son iguales"""
        return 0
    
    def __eq__(self, other): #eq = equal
        return self.cmp(other) == 0
    
    def __ge__(self, other): #ge = greater and equal
        return self.cmp(other) >= 0
    
    def __le__(self, other): #le = lesser and equal
        return self.cmp(other) <= 0
    
    def __gt__(self, other): #gt = greater than
        return self.cmp(other) > 0
    
    def __lt__(self, other): #lt = lesser than
        return self.cmp(other) < 0
    
    def __ne__(self, other): #ne = not equal
        return self.cmp(other) != 0

#7 de diamantes
carta1 = Carta(palo=1, rango=7)
#K de picas
carta2 = Carta(palo=3, rango=13)

print(carta1)
print(carta2)

#Uso de sobrecarga de operadores
if carta1 < carta2:
    print("carta1 es menor que carta 2")
if carta1 > carta2:
    print("carta1 es mayor que carta 2")
if carta1 >= carta2:
    print("carta1 es mayor o igual que carta 2")
if carta1 <= carta2:
    print("carta1 es menor o igual que carta 2")
if carta1==carta2:
    print("carta1 es igual a carta 2")
if carta1!=carta2:
    print("carta1 es diferente a carta 2")
    
    
#Coleccion de objetos   
class Baraja:
    
    def __init__(self):
        self.cartas = []   #lista que va a almacenar las cartas
        for palo in range(4):  #construye la baraja
            for rango in range(1,14):
                self.cartas.append(Carta(palo,rango))
    
    def __str__(self):     #Imprime la baraja
        s = ""
        for i in range(len(self.cartas)):
            s = s + " "*i + str(self.cartas[i]) + "\n"
        return s
    
    def barajar(self): 
        import random
    
        rng = random.Random()
        num_cartas = len(self.cartas)
    
        for i in range(num_cartas):
            j = rng.randrange(i, num_cartas)  #Selecciona un numero aleatorio
            (self.cartas[i],self.cartas[j]) = (self.cartas[j],self.cartas[i]) #Invierte j con i

    def remover(self, carta): #Remueve una carta de la baraja
        if carta in self.cartas:
            self.cartas.remove(carta)
            return True
        else:
            return False

    def pop(self): #quita la última carta en la baraja y la retorna
        return self.cartas.pop()

    def vacia(self): #Vacia la baraja
        return self.cartas == []

mibaraja = Baraja()
print(mibaraja)
mibaraja.barajar()
print(mibaraja)
mibaraja.pop()
print(mibaraja)
carta9 = Carta(2,1) #Az de corazones
print(carta9)
mibaraja.remover(carta9)


""" Ejercicio de Colecciones de Objetos
Parte I:Tomando como ejemplo la clase carta y la clase barajas, implemente una 
clase llamada vehiculo que contenga la información:
Atributos:
    carga: int. Capacidad de carga. Valores permitidos [1-10]
    pasajeros: int. numero de pasajeros. Valores permitidos [2-5]
Metodos:
__init__: construye Vehiculo inicializando atributos
__str__: retorna str con el estado de un Vehiculo

Cree al menos 2 objetos de tipo vehiculo y pruebe el metodo __str__ 

Parte II: Implemente una clase llamada "Flota" que representa una flota de 
objetos de tipo vehiculo. Esta clase debe tener los siguientes metodos:
   __init__ : contruye un objeto flota con 5 objetos de tipo Vehiculo generados
   automaticamente con valores aleatorios para los atributos
   __str__: Permite imprimir todos los objetos que hacen parte de la flota
        
Finalmente cree un objeto de tipo Flota y pruebe el metodo __str__ 
"""
class vehiculo:
    def __init__(self):
        import random
        rng1 = random.Random()
        self.carga = rng1.randint(1,10) #obtienen un numero aleatorio para la carga
        self.pasajeros = rng1.randint(2,5) #obtienen un numero aleatorio para los pasajeros
    
    def __str__(self):
            return str(self.carga) + " de carga con " + str(self.pasajeros) + " pasajeros"
        
class flota:
    def __init__(self):
        self.vehiculos = []
        for x in range(5):  #Con el for se crea una lista (coleccion) de 5 vehiculos, x=0 ... x=4
            self.vehiculos.append(vehiculo())
                    
    def __str__(self):
        z = ""
        for i in range(len(self.vehiculos)):
            #z = z + str(self.vehiculos[i])+"\n"
            z = z + str(self.vehiculos[i])+"\n"
        return z
                        
vehiculos = flota()
print(vehiculos)











