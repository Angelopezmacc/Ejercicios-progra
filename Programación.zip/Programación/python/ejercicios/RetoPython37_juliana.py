#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 06:55:54 2020

@author: daniel
"""

#class Carta:
#    
#    palos = ["Tréboles","Diamantes","Corazones","Picas"]
#    rangos = ["-","Az","2","3","4","5","6","7","8","9", "10","J","Q","K"]
#    
#    def __init__(self, palo=0, rango=0):
#        self.palo = palo
#        self.rango = rango
#    
#    def __str__(self):
#        return self.rangos[self.rango] + " de " + self.palos[self.palo]
#    
#    def cmp(self,other):
#        """Compara palos"""
#        if self.palo > other.palo: return 1
#        if self.palo < other.palo: return -1
#        """Palos son iguales, compara rango"""
#        if self.rango > other.rango: return 1
#        if self.rango < other.rango: return -1
#        """Cartas son iguales"""
#        return 0
#    
#    def __eq__(self, other): #eq = equal
#        return self.cmp(other) == 0
#    
#    def __ge__(self, other): #ge = greater and equal
#        return self.cmp(other) >= 0
#    
#    def __le__(self, other): #le = lesser and equal
#        return self.cmp(other) <= 0
#    
#    def __gt__(self, other): #gt = greater than
#        return self.cmp(other) > 0
#    
#    def __lt__(self, other): #lt = lesser than
#        return self.cmp(other) < 0
#    
#    def __ne__(self, other): #ne = not equal
#        return self.cmp(other) != 0
#
##7 de diamantes
#carta1 = Carta(palo=1, rango=7)
##K de picas
#carta2 = Carta(palo=3, rango=13)
#
#print(carta1)
#print(carta2)
#
##Uso de sobrecarga de operadores
#if carta1 < carta2:
#    print("carta1 es menor que carta 2")
#if carta1 > carta2:
#    print("carta1 es mayor que carta 2")
#if carta1 >= carta2:
#    print("carta1 es mayor o igual que carta 2")
#if carta1 <= carta2:
#    print("carta1 es menor o igual que carta 2")
#if carta1==carta2:
#    print("carta1 es igual a carta 2")
#if carta1!=carta2:
#    print("carta1 es diferente a carta 2")
#    
#    
##Coleccion de objetos   
#class Baraja:
#    
#    def __init__(self):
#        self.cartas = []   #lista que va a almacenar las cartas
#        for palo in range(4):  #construye la baraja
#            for rango in range(1,14):
#                self.cartas.append(Carta(palo,rango))
#    
#    def __str__(self):     #Imprime la baraja
#        s = ""
#        for i in range(len(self.cartas)):
#            s = s + " "*i + str(self.cartas[i]) + "\n"
#        return s
#    
#    def barajar(self): 
#        import random
#    
#        rng = random.Random()
#        num_cartas = len(self.cartas)
#    
#        for i in range(num_cartas):
#            j = rng.randrange(i, num_cartas)  #Selecciona un numero aleatorio
#            (self.cartas[i],self.cartas[j]) = (self.cartas[j],self.cartas[i]) #Invierte j con i
#
#    def remover(self, carta): #Remueve una carta de la baraja
#        if carta in self.cartas:
#            self.cartas.remove(carta)
#            return True
#        else:
#            return False
#
#    def pop(self): #quita la última carta en la baraja y la retorna
#        return self.cartas.pop()
#
#    def vacia(self): #Vacia la baraja
#        return self.cartas == []
#
#mibaraja = Baraja()
#print(mibaraja)
#mibaraja.barajar()
#print(mibaraja)
#mibaraja.pop()
#print(mibaraja)
#carta9 = Carta(2,1) #Az de corazones
#print(carta9)
#mibaraja.remover(carta9)


""" Ejercicio de Colecciones de Objetos
Parte I:Tomando como ejemplo la clase carta y la clase barajas, implemente una 
clase llamada Transferencia que contenga la información básica de una transferencia 
electrónica entre cuentas, es decir: banco de origen, cuenta de origen, 
cuenta de destino, banco de destino, monto transferido.
Para la asignación de los bancos utilizar la siguiente lista: 
nombres_bancos = ["BBVA","ITAU","BANCOLOMBIA","COLPATRIA", "DAVIVIENDA"]
Implemente los métodos siguientes para esta clase: __init__,
__str__, y adicionalmente implemente métodos que permitan comparar el monto de 
las transferencias: cmp, ==, >=, <=, >, <, y !=: 

Finalmente cree varios objetos de tipo Transferencia y realice pruebas con ellos 
de los métodos implementados previamente """


#class Transferencia:
#    nombres_bancos = ["BBVA","ITAU","BANCOLOMBIA","COLPATRIA", "DAVIVIENDA"]
#    
#    def __init__(self,B_origen,C_origen,B_destino,C_destino,monto):
#      #--Your code here--
#      #--Your code here--
#        
#    def __str__(self):
#      #--Your code here--
#    
#    def comp(self,other):
#        
#        if self.monto>other.monto:
#            return 1
#        if self.monto<other.monto:
#            return -1
#        return 0
#    
#    def __eq__(self,other):
#        #--Your code here--
#    def __ge__(self,other):
#        #--Your code here--
#    def __le__(self,other):
#        #--Your code here--
#    def __lt__(self,other):
#        #--Your code here--
#    def __gt__(self,other):
#        #--Your code here--
#    def __ne__(self,other):
#        #--Your code here--
#    
#trans1=Transferencia(2,5318560431,1,6123422123,3000000)
#trans2=Transferencia(1,5499504321,4,4432354563,534000)
#print(trans1)
#print(trans2)
#trans1.comp(trans2)
#print(trans1==trans2)
#print(trans1>=trans2)
#print(trans1<=trans2)

"""
Parte II: Implemente una clase llamada "Libro_de_cuentas" que agrupe un conjunto 
de objetos de tipo Transferencia. Igualmente implemente los siguientes metodos: 
   __init__ : contruye un objeto Libro_de_cuentas con 10 objetos Transferencia generadas automaticamente
   __str__: Permite imprimir los objetos Transferencia del libro de cuentas
   agregar_transferencia(transferenciaN): Permite agregar un objeto Transferenia al libro de cuentas
   borrar_transferencia(transferenciaN): Permite borrar un objeto Transferencia del libro de cuentas
   vaciar(): Permite borrar todos los objetos Transferencia del libro de cuentas
   backup(): Realiza una copia de seguridad del libro de cuentas
   consultar(transferenciaN): Permite consultar los datos de un objeto Transferencia del libro de cuentas
        
Finalmente cree un objeto de tipo Libro_de_cuentas y realice prueba con el usando 
los métodos implementados previamente. 
 """

#class Libro_de_cuentas:
#        
#    def __init__(self):
#        #---Your code here---
#    
#    def __str__(self):
#        #---Your code here---
#    
#    def agregar_transferencia(self,trans1):
#        #---Your code here---
#        
#    def borrar_transferencia(self,trans):
#        #---Your code here---
#    
#    def borrar(self):
#        #---Your code here---
#        
#    def backup(self):
#        #---Your code here---
#    
#    def consultar(self, trans1):
#        #---Your code here---
#        
#
#listas=Libro_de_cuentas() #se crea el objeto libro de cuentas que contiene 10 objetos transferencia generados al azar       
#print(listas) #se imprime el objeto y se imprime su longitud
#print(len(listas.list_cuentas)) 
#transN=Transferencia(3,423232411,4,605043231,450000) #se usa el metodo de agregar_transferencia y se imprime la longitud para verificar que si lo agrego
#listas.agregar_transferencia(transN)
#print(listas)
#print(listas.consultar(transN)) #se consulta por esta transferencia en particular
#listas.borrar_transferencia(transN) #se usa el metodo de borrar_transferencia y se imprime el objeto para ver si la quitó
#print(listas)
#co_seguridad=listas.backup() #se genera una copia de seguridad
#listas.borrar() #Se borran todas las transferencias
#print(listas) 
#print(co_seguridad)
 
class Transferencia:
    nombres_bancos = ["BBVA","ITAU","BANCOLOMBIA","COLPATRIA", "DAVIVIENDA"]
    
    def __init__(self,B_origen,C_origen,B_destino,C_destino,monto):
        self.BancoOrigen = B_origen
        self.CuentaOrigen = C_origen
        self.BancoDestino = B_destino
        self.CuentaDestino = C_destino
        self.monto = monto

        
    def __str__(self):
      return "El banco de origen es: {0}\n La cuenta de origen es: {1}\n El banco de destino es: {2}\n La cuenta de destino es: {3}\n El monto transferido es: {4}".format(self.nombres_bancos[self.BancoOrigen], self.CuentaOrigen, self.nombres_bancos[self.BancoDestino], self.CuentaDestino, self.monto )
    
    def comp(self,other):
        
        if self.monto>other.monto:
            return 1   #monto de la primera mayor que la segunda
        if self.monto<other.monto:
            return -1  #monto de la segunda mayor que la primera
        return 0       #los montos son iguales
    
    def __eq__(self,other): #equal
        if self.comp(other) == 0:
            return True
        else:
            return False
        #return self.comp(other) == 0
    
    def __ge__(self,other):
        return self.comp(other) >= 0
    
    def __le__(self,other):
        return self.comp(other) <= 0

    def __lt__(self,other):
        return self.comp(other) > 0
    
    def __gt__(self,other):
        return self.comp(other) < 0
    
    def __ne__(self,other):
        return self.cmp(other) != 0
    
trans1=Transferencia(2,5318560431,1,6123422123,3000000)
print(trans1)
trans2=Transferencia(1,5499504321,4,4432354563,534000)
print(trans2)

#trans1.comp(trans2)
#print(trans1==trans2)

if trans1==trans2:
    print("son iguales")
else:
    print("son diferentes")

print(trans1>=trans2)
print(trans1<=trans2)


class Libro_de_cuentas:
        
    def __init__(self):
        self.transferencias = []   #lista que va a almacenar las transferencias
        
        import random 
        nombres_bancos = list(range(5))
        monto = [20000,50000,100000,300000,500000,1000000]
        cuenta = [123456789,234567891,345678912,456789123,567891234,678912345]

        for i in range(10):
            a = Transferencia(random.choice(nombres_bancos), random.choice(cuenta), random.choice(nombres_bancos), random.choice(cuenta), random.choice(monto))
            self.transferencias.append(a)        
    
    def __str__(self):
        L = ""
        for i in range(len(self.transferencias)):
            L = L + " "*i + str(self.transferencias[i]) + "\n"
        return L
        
    def agregar_transferencia(self,trans1):
        self.transferencias.append(trans1)
        
    def borrar_transferencia(self,trans):
        for i in self.transferencias:
            if i == trans:
                self.transferencias.remove(i)
    
    def borrar(self):
        self.transferencias.clear()
        
    def backup(self):
        backuplist = []
        print(len(self.transferencias))
        for i in self.transferencias:
            backuplist.append(str(i))
        return backuplist

    def consultar(self, trans1):
        for i in self.transferencias:
            if i == trans1:
                return i
        

listas=Libro_de_cuentas() #se crea el objeto libro de cuentas que contiene 10 objetos transferencia generados al azar       
print(listas) #se imprime el objeto y se imprime su longitud
print(len(listas.transferencias)) 

transN=Transferencia(3,423232411,4,605043231,450000) #se usa el metodo de agregar_transferencia y se imprime la longitud para verificar que si lo agrego
listas.agregar_transferencia(transN)
print(listas)

print(listas.consultar(transN)) #se consulta por esta transferencia en particular

listas.borrar_transferencia(transN) #se usa el metodo de borrar_transferencia y se imprime el objeto para ver si la quitó
print(listas)

co_seguridad=listas.backup() #se genera una copia de seguridad
listas.borrar() #Se borran todas las transferencias
print(listas) 
print("backup", co_seguridad)
        
        