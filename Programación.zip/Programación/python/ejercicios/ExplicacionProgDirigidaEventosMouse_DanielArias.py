#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 22 08:10:21 2020

@author: daniel
"""

'''
Construir un programa dado que cuando se presione un boton del mouse tecla provoque las siguientes acciones:
    click derecho del mouse: Manuelita gira 90 grados a la izquierda y avanza 20 unidades
    click izquierdo del mouse: Manuelita gira 90 grados a la derecha y avanza 20 unidades
    click medio del mouse: Manuelita avanza 20 unidades al frente
'''


import turtle
turtle.setup(400,500)
wn = turtle.Screen()
manuelita = turtle.Turtle()
manuelita.color("purple")


def manipulador_para_manuelita(x,y):
    wn.title("Manuelita clicked at {0}, {1}".format(x, y))
    manuelita.left(90)
    manuelita.forward(20)
def manipulador2_para_manuelita(x,y):
    wn.title("Manuelita clicked at {0}, {1}".format(x,y))
    manuelita.right(90)
    manuelita.forward(20)
def manipulador3_para_manuelita(x,y):
    wn.title("Manuelita clicked at {0}, {1}".format(x,y))
    manuelita.forward(20)
    
manuelita.onclick(manipulador_para_manuelita) #Por default es el numero 1 - click izquierdo
manuelita.onclick(manipulador2_para_manuelita,3) #Click derecha
manuelita.onclick(manipulador3_para_manuelita,2) #Click del medio
turtle.mainloop()
turtle.bye()


'''
1 - left click (by default)
2 - middle click
3 - right click
4 - scroll up
5 - scroll down
'''















