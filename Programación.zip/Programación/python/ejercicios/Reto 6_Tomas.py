#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 14 07:23:44 2020

@author: daniel
"""

import turtle

#Here define the function (the NEW-INSTRUCTION remembering to Karel)
def estrella(t, size):
    """La tortuga t dibuja una estrella de lado size"""
    for i in range(5):
       t.forward(size)
       t.left((360)/(5/2))        


#Here start the code that use the functions (the BEGIN-OF-EXECUTION remembering to karel)
turtle.setup(400,300)
wn = turtle.Screen()
wn.bgcolor("lightgreen")

manuelita = turtle.Turtle()
manuelita.color("red")
estrella(manuelita, 500)

alex = turtle.Turtle()
alex.color("blue")
estrella(alex, 500) 


turtle.mainloop()
turtle.done()
turtle.bye()