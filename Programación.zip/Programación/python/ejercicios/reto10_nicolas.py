#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 09:07:28 2020

@author: hipatia
"""

def interes_compuesto (p,n,r,t):  #esta funcion hace ...
    a=p*(1+r/n)**(n*t)
    return a      #aqui se retorna ..

t=float(input("ingrese el numero del año:"))
a= interes_compuesto(10000,12,8,t)
print(a)

