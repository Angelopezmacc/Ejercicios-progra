#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 17 11:36:00 2020

@author: daniel
"""
'''
Dada la implementación de la clase Abeja (mostrada abajo), implemente las clases hijas:
    
    Reina (con los métodos ponerHuevos que imprime Pongo huevos! y emitirFeromonas
           que imprime Emito feromonas! )
    Obrera (con los métodos recolectarPolen que imprime Recolecto! , producirMiel que 
    imprime Hago miel! y picar que imprime Pico! )  

    Zangano (con el método fecundar que imprime Fecundo! )
 '''   
class Abeja (object) :
    def __init__ ( self , sp = " apis mellifera " ) :
        self . especie = sp
    def volar ( self ) :
        print ( " Estoy volando ! " )
    def alimentarse ( self ) :
        print ( " Me estoy alimentando ! " )
    def darReina(self):   #Se inventaron
        print("¡Doy a luz a la reina!")

class Reina(Abeja):
    def ponerHuevos(self):
        print("¡Pongo huevos!")  
    def emitirFeromonas(self):
        print("¡Emito Feromonas!")
        
class Obrera(Abeja):
    def recolectarPolen():
        print("¡Recolecto!")
    def producirMiel(self):
        print("¡Hago miel")
    def picar(self):
        print("¡Pico!")
    def darReina(self): #Se inventaron
        print("¡Doy a luz a los zánganos!")

class Zángano(Abeja):
    def fecundar(self):
        print("¡Fecundo!")
    def alimentarse(self): #Ejemplo de herencia con altered
        print("Me voy a alimentar")        
        super(Zángano,self).alimentarse() #Se invoca el metodo de la clase madre con super()
        print("Ya me alimente")        
        self.volar()
       
class Enjambre:
    def __init__(self,Reina=0,Zángano=0,Obrera=0):
        self.Reina=Reina
        self.Zángano=Zángano
        self.Obrera=Obrera
    def __str__(self):
        return "{0} Reina(s), {1} Obreras y {2} Zánganos".format(self.Reina, self.Obrera, self.Zángano)
    
    def fundarColmena(self):
        if self.Reina>=1 and self.Zángano>=1 and self.Obrera>=3:
            print("¡Fundamos una colmena!")
            
        else:
            print("¡Somos muy pocos!")
    
    def  defenderColmena(self):
        print("¡Defendamos la colmena!")
        for i in range(self.Obrera):
            print(" ")
            Obrera.picar(self)
            
Enjambre=Enjambre(1,1,5)
print(Enjambre)
Enjambre.fundarColmena()
Enjambre.defenderColmena()
'''
Invente un metodo adicional que esta en la clase Abeja y que la clase Obrera hereda de manera explicita 
Invente un metodo adicional que esta en la clase Abeja y que la clase Zangano hereda con alteración

Implemente luego la clase Enjambre , que contiene una reina, una cantidad m de
zánganos y una cantidad n de obreras (estos parámetros se pasan al constructor,
quien crea las abejas y las guarda en listas). El enjambre tiene las capacidades de
fundarColmena , que requiere al menos una reina, un zángano y 3 obreras para impri-
mir Fundamos una colmena! (o imprimir Somos muy pocos! en caso de no cumplir
con los requerimientos) y defenderColmena , que hace que todas las obreras de la
colmena piquen.
Finalmente cree una colmena con una reina, 2 zánganos y 3 obreras, funde una
colmena y defiéndala.
'''