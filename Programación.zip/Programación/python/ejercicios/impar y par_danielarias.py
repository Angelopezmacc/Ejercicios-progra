#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 09:19:01 2020

@author: hipatia
"""

a = [1,2,3,4,5,6,7,8,9]
impares = 0
pares = 0
for x in a:
    if x%2 == 0:
        pares = pares + 1
    else:
        impares = impares +1
        
print("losnumeros pares son:",pares)
print("los numeros impares son:",impares)












        
         
